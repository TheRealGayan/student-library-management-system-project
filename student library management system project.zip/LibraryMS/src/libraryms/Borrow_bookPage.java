/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package libraryms;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.*;
import javax.swing.JOptionPane;
/**
 *
 * @author ACER
 */
public class Borrow_bookPage extends javax.swing.JFrame {

    /**
     * Creates new form Borrow_bookPage
     */
    public Borrow_bookPage() {
        initComponents();
    }

    //get book_details from the database and display it on book details pannel
    public void display_bookdetails(){
        int book_id=Integer.parseInt(Book_IDtxt.getText());
        
        try {
             Connection con=DBconnection.getconnection();
             PreparedStatement pst=con.prepareStatement("Select * from book_details where Book_ID=?");
             pst.setInt(1,book_id);
             ResultSet rs=pst.executeQuery();
             
             while(rs.next()){
                 Book_IDlbl.setText(rs.getString("Book_ID"));
                 Book_Namelbl.setText(rs.getString("Book_Name"));
                 Authorlbl.setText(rs.getString("Author"));
                 Quantitylbl.setText(rs.getString("Quantity"));
                
                }
            
        } catch (Exception e) {
           System.out.println(""+e);
        }
    
  }
    
     //get member_details from the database and display it on member details pannel
    public void display_memberdetails(){
        int member_id=Integer.parseInt(Member_IDtxt.getText());
        
        try {
             Connection con=DBconnection.getconnection();
             PreparedStatement pst=con.prepareStatement("Select * from registration where Member_ID=?");
             pst.setInt(1,member_id);
             ResultSet rs=pst.executeQuery();
             
             while(rs.next()){
                 MemberIDlbl.setText(rs.getString("Member_ID"));
                 MemberNamelbl.setText(rs.getString("Name"));
                 Addresslbl.setText(rs.getString("Address"));
                 Emaillbl.setText(rs.getString("Email"));
                 Contactlbl.setText(rs.getString("Contact"));
                }
            
        } catch (Exception e) {
           System.out.println(""+e);
        }
    }
    
    //insert values for borrowbook_details
    public void borrowbook(){
        int book_id=Integer.parseInt(Book_IDtxt.getText());
        int member_id=Integer.parseInt(Member_IDtxt.getText());
        String book_name=Book_Namelbl.getText();
        String member_name=MemberNamelbl.getText();
        
        Date borrow_date=I_Datefecha.getDatoFecha();
        Date due_date=d_Datefecha.getDatoFecha();
        
        Long i=borrow_date.getTime();
        Long d=due_date.getTime();
        
        java.sql.Date iborrow_date=new java.sql.Date(i);
        java.sql.Date idue_date=new java.sql.Date(d);
        
        try {
            Connection con=DBconnection.getconnection();
            String query="Insert into borrowbook_details(Book_ID,Book_Name,Member_ID,Member_Name,Borrow_Date,Due_Date,Status)values(?,?,?,?,?,?,?)";
            PreparedStatement pst=con.prepareStatement(query);
            
            pst.setInt(1,book_id);
            pst.setString(2,book_name);
            pst.setInt(3,member_id);
            pst.setString(4,member_name);
            pst.setDate(5,iborrow_date);
            pst.setDate(6,idue_date);
            pst.setString(7,"pending");
            
            int RowCount=pst.executeUpdate();
            
            if(RowCount>0){
                JOptionPane.showMessageDialog(this,"Book borrowed successfully");
               
            }
            
            else{
                JOptionPane.showMessageDialog(this,"Book not borrowed");
            }
        } catch (Exception e) {
             System.out.println(""+e);
        }
    }
    
    // update book count method
    public void update_bookcount(){
        int bookid=Integer.parseInt(Book_IDtxt.getText());
        
        try {
           Connection con=DBconnection.getconnection();
           String query="Update book_details set Quantity=Quantity-1 where Book_ID=?";
           PreparedStatement pst=con.prepareStatement(query);
           
           pst.setInt(1,bookid);
           
           int RowCount=pst.executeUpdate();
            
            if(RowCount>0){
                //JOptionPane.showMessageDialog(this,"Book count updated successfully");
                int book_count=Integer.parseInt(Quantitylbl.getText());
                Quantitylbl.setText(Integer.toString(book_count-1));
            }
            
            else{
                //JOptionPane.showMessageDialog(this,"Book count not updated");
            }
              
        } catch (Exception e) {
          System.out.println(""+e);
        }
    }
    
     //method to prevent duplicate 
     public boolean already_borrowed(){
          boolean already_borrow=false;
          int book_id=Integer.parseInt(Book_IDtxt.getText());
          int member_id=Integer.parseInt(Member_IDtxt.getText());
          
          
          try {
           Connection con=DBconnection.getconnection();
           String query="select * from borrowbook_details where Book_ID=? and Member_ID=? and Status=?";
           PreparedStatement pst=con.prepareStatement(query);
           
           pst.setInt(1,book_id);
           pst.setInt(2,member_id);
           pst.setString(3, "pending");
           
           ResultSet rs=pst.executeQuery();
           
              if (rs.next()) {
                already_borrow=true;
               }             
    
              else{
                 already_borrow=false;
                        
               } 
                  
              }catch (Exception e) {
            System.out.println(""+e);
          }
          return already_borrow;
        }          
  
      
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        kGradientPanel2 = new keeptoo.KGradientPanel();
        cancellbl = new javax.swing.JLabel();
        backbtn = new rojerusan.RSMaterialButtonCircle();
        jLabel1 = new javax.swing.JLabel();
        kGradientPanel1 = new keeptoo.KGradientPanel();
        jLabel4 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        D_Datefecha = new javax.swing.JLabel();
        Member_IDtxt = new javax.swing.JTextField();
        d_Datefecha = new rojeru_san.componentes.RSDateChooser();
        I_Datefecha = new rojeru_san.componentes.RSDateChooser();
        Book_IDtxt = new javax.swing.JTextField();
        Borrowbookbtn = new rojerusan.RSMaterialButtonCircle();
        kGradientPanel3 = new keeptoo.KGradientPanel();
        Emaillbl = new javax.swing.JLabel();
        Addresslbl = new javax.swing.JLabel();
        MemberNamelbl = new javax.swing.JLabel();
        MemberIDlbl = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        Contactlbl = new javax.swing.JLabel();
        kGradientPanel4 = new keeptoo.KGradientPanel();
        Book_Namelbl = new javax.swing.JLabel();
        Authorlbl = new javax.swing.JLabel();
        Book_IDlbl = new javax.swing.JLabel();
        Quantitylbl = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        kGradientPanel2.setkEndColor(new java.awt.Color(0, 0, 51));
        kGradientPanel2.setkStartColor(new java.awt.Color(51, 0, 255));
        kGradientPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        cancellbl.setFont(new java.awt.Font("Segoe UI Semibold", 1, 30)); // NOI18N
        cancellbl.setForeground(new java.awt.Color(153, 0, 0));
        cancellbl.setText("X");
        cancellbl.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cancellblMouseClicked(evt);
            }
        });
        kGradientPanel2.add(cancellbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(1474, 15, -1, 30));

        backbtn.setText("Back");
        backbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backbtnActionPerformed(evt);
            }
        });
        kGradientPanel2.add(backbtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(22, 16, 136, 51));

        jLabel1.setFont(new java.awt.Font("Segoe UI Semibold", 1, 50)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(153, 0, 0));
        jLabel1.setText("Borrow Books");
        kGradientPanel2.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 0, 428, -1));

        getContentPane().add(kGradientPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1540, 80));

        kGradientPanel1.setkEndColor(new java.awt.Color(204, 255, 255));
        kGradientPanel1.setkStartColor(new java.awt.Color(255, 255, 255));
        kGradientPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel4.setFont(new java.awt.Font("Segoe UI Semibold", 1, 30)); // NOI18N
        jLabel4.setText("Borrow Book");
        kGradientPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 50, 190, 30));

        jLabel23.setBackground(new java.awt.Color(0, 0, 0));
        jLabel23.setFont(new java.awt.Font("Segoe UI Semibold", 1, 18)); // NOI18N
        jLabel23.setText("Member ID");
        kGradientPanel1.add(jLabel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 260, 100, 30));

        jLabel24.setFont(new java.awt.Font("Segoe UI Semibold", 1, 18)); // NOI18N
        jLabel24.setText("Book ID");
        kGradientPanel1.add(jLabel24, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 180, 100, 30));

        jLabel25.setFont(new java.awt.Font("Segoe UI Semibold", 1, 18)); // NOI18N
        jLabel25.setText("Issue Date");
        kGradientPanel1.add(jLabel25, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 370, 100, 30));

        D_Datefecha.setFont(new java.awt.Font("Segoe UI Semibold", 1, 18)); // NOI18N
        D_Datefecha.setText("Due Date");
        kGradientPanel1.add(D_Datefecha, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 460, 100, 30));

        Member_IDtxt.setFont(new java.awt.Font("Segoe UI Semibold", 1, 20)); // NOI18N
        Member_IDtxt.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 2, 0, new java.awt.Color(0, 0, 0)));
        Member_IDtxt.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                Member_IDtxtFocusLost(evt);
            }
        });
        kGradientPanel1.add(Member_IDtxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 260, 190, 30));

        d_Datefecha.setPlaceholder("Select Return Date");
        kGradientPanel1.add(d_Datefecha, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 460, -1, 30));

        I_Datefecha.setPlaceholder("Select Borrow Date");
        kGradientPanel1.add(I_Datefecha, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 370, -1, 30));

        Book_IDtxt.setFont(new java.awt.Font("Segoe UI Semibold", 1, 20)); // NOI18N
        Book_IDtxt.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 2, 0, new java.awt.Color(0, 0, 0)));
        Book_IDtxt.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                Book_IDtxtFocusLost(evt);
            }
        });
        kGradientPanel1.add(Book_IDtxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 180, 190, 30));

        Borrowbookbtn.setBackground(new java.awt.Color(0, 102, 51));
        Borrowbookbtn.setText("Borrow Book");
        Borrowbookbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BorrowbookbtnActionPerformed(evt);
            }
        });
        kGradientPanel1.add(Borrowbookbtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 600, 210, 60));

        getContentPane().add(kGradientPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(960, 80, 540, 920));

        kGradientPanel3.setkEndColor(new java.awt.Color(0, 204, 255));
        kGradientPanel3.setkStartColor(new java.awt.Color(0, 204, 255));
        kGradientPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Emaillbl.setFont(new java.awt.Font("Segoe UI Semibold", 3, 20)); // NOI18N
        Emaillbl.setForeground(new java.awt.Color(255, 255, 255));
        kGradientPanel3.add(Emaillbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 460, 220, 30));

        Addresslbl.setFont(new java.awt.Font("Segoe UI Semibold", 1, 20)); // NOI18N
        Addresslbl.setForeground(new java.awt.Color(255, 255, 255));
        kGradientPanel3.add(Addresslbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 360, 220, 30));

        MemberNamelbl.setFont(new java.awt.Font("Segoe UI Semibold", 1, 20)); // NOI18N
        MemberNamelbl.setForeground(new java.awt.Color(255, 255, 255));
        kGradientPanel3.add(MemberNamelbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 270, 220, 30));

        MemberIDlbl.setFont(new java.awt.Font("Segoe UI Semibold", 1, 20)); // NOI18N
        MemberIDlbl.setForeground(new java.awt.Color(255, 255, 255));
        kGradientPanel3.add(MemberIDlbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 190, 220, 30));

        jLabel3.setFont(new java.awt.Font("Segoe UI Semibold", 1, 30)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Student Details");
        kGradientPanel3.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 40, -1, 40));

        jLabel9.setFont(new java.awt.Font("Segoe UI Semibold", 1, 20)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("Member ID :");
        kGradientPanel3.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 190, 120, 30));

        jLabel10.setFont(new java.awt.Font("Segoe UI Semibold", 1, 20)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("Member Name :");
        kGradientPanel3.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 270, 150, 30));

        jLabel11.setFont(new java.awt.Font("Segoe UI Semibold", 1, 20)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("Address :");
        kGradientPanel3.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 360, 90, 30));

        jLabel21.setFont(new java.awt.Font("Segoe UI Semibold", 1, 20)); // NOI18N
        jLabel21.setForeground(new java.awt.Color(255, 255, 255));
        jLabel21.setText("Email :");
        kGradientPanel3.add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 460, 80, 30));

        jLabel12.setFont(new java.awt.Font("Segoe UI Semibold", 1, 20)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(255, 255, 255));
        jLabel12.setText("Contact :");
        kGradientPanel3.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 560, 90, 30));

        Contactlbl.setFont(new java.awt.Font("Segoe UI Semibold", 3, 20)); // NOI18N
        Contactlbl.setForeground(new java.awt.Color(255, 255, 255));
        kGradientPanel3.add(Contactlbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 560, 220, 30));

        getContentPane().add(kGradientPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 80, 460, 920));

        kGradientPanel4.setkEndColor(new java.awt.Color(0, 102, 102));
        kGradientPanel4.setkStartColor(new java.awt.Color(0, 102, 102));
        kGradientPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Book_Namelbl.setFont(new java.awt.Font("Segoe UI Semibold", 0, 20)); // NOI18N
        Book_Namelbl.setForeground(new java.awt.Color(255, 255, 255));
        kGradientPanel4.add(Book_Namelbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 270, 220, 30));

        Authorlbl.setFont(new java.awt.Font("Segoe UI Semibold", 1, 20)); // NOI18N
        Authorlbl.setForeground(new java.awt.Color(255, 255, 255));
        kGradientPanel4.add(Authorlbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 370, 200, 30));

        Book_IDlbl.setFont(new java.awt.Font("Segoe UI Semibold", 1, 20)); // NOI18N
        Book_IDlbl.setForeground(new java.awt.Color(255, 255, 255));
        kGradientPanel4.add(Book_IDlbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 190, 220, 30));

        Quantitylbl.setFont(new java.awt.Font("Segoe UI Semibold", 1, 20)); // NOI18N
        Quantitylbl.setForeground(new java.awt.Color(255, 255, 255));
        kGradientPanel4.add(Quantitylbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 460, 220, 30));

        jLabel2.setFont(new java.awt.Font("Segoe UI Semibold", 1, 30)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Book Details");
        kGradientPanel4.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 30, 190, 50));

        jLabel6.setFont(new java.awt.Font("Segoe UI Semibold", 1, 20)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Book_ID :");
        kGradientPanel4.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 190, 90, 30));

        jLabel7.setFont(new java.awt.Font("Segoe UI Semibold", 1, 20)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Book_Name :");
        kGradientPanel4.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 270, 120, 30));

        jLabel8.setFont(new java.awt.Font("Segoe UI Semibold", 1, 20)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Author :");
        kGradientPanel4.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 370, 80, 30));

        jLabel5.setFont(new java.awt.Font("Segoe UI Semibold", 1, 20)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Quantity :");
        kGradientPanel4.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 460, 90, 30));

        getContentPane().add(kGradientPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 80, 460, 920));

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 60, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 920, Short.MAX_VALUE)
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 80, 60, 920));

        setSize(new java.awt.Dimension(1515, 1007));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents
    
    //cancel button
    private void cancellblMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cancellblMouseClicked
        System.exit(0);
    }//GEN-LAST:event_cancellblMouseClicked
   
     //back button
    private void backbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backbtnActionPerformed
        UserHome_page uh1=new UserHome_page();
        uh1.setVisible(true);
        dispose();
    }//GEN-LAST:event_backbtnActionPerformed

    private void Book_IDtxtFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_Book_IDtxtFocusLost
        if(!Book_IDtxt.getText().equals("")){
            display_bookdetails();
        }
    }//GEN-LAST:event_Book_IDtxtFocusLost

    private void Member_IDtxtFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_Member_IDtxtFocusLost
        if(!Member_IDtxt.getText().equals("")){
            display_memberdetails();
        }
    }//GEN-LAST:event_Member_IDtxtFocusLost
    
    //borrow book button
    private void BorrowbookbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BorrowbookbtnActionPerformed
        if(Quantitylbl.getText().equals("0")){
            JOptionPane.showMessageDialog(this, "The book is not available");
        }
        else{
          if(already_borrowed()==false){
            borrowbook();
            update_bookcount();
        }
          else{
            JOptionPane.showMessageDialog(this, "You can't borrow this book");  
         }
          
        }     
    }//GEN-LAST:event_BorrowbookbtnActionPerformed
       
   
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Borrow_bookPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Borrow_bookPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Borrow_bookPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Borrow_bookPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Borrow_bookPage().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Addresslbl;
    private javax.swing.JLabel Authorlbl;
    private javax.swing.JLabel Book_IDlbl;
    private javax.swing.JTextField Book_IDtxt;
    private javax.swing.JLabel Book_Namelbl;
    private rojerusan.RSMaterialButtonCircle Borrowbookbtn;
    private javax.swing.JLabel Contactlbl;
    private javax.swing.JLabel D_Datefecha;
    private javax.swing.JLabel Emaillbl;
    private rojeru_san.componentes.RSDateChooser I_Datefecha;
    private javax.swing.JLabel MemberIDlbl;
    private javax.swing.JLabel MemberNamelbl;
    private javax.swing.JTextField Member_IDtxt;
    private javax.swing.JLabel Quantitylbl;
    private rojerusan.RSMaterialButtonCircle backbtn;
    private javax.swing.JLabel cancellbl;
    private rojeru_san.componentes.RSDateChooser d_Datefecha;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private keeptoo.KGradientPanel kGradientPanel1;
    private keeptoo.KGradientPanel kGradientPanel2;
    private keeptoo.KGradientPanel kGradientPanel3;
    private keeptoo.KGradientPanel kGradientPanel4;
    // End of variables declaration//GEN-END:variables
}
