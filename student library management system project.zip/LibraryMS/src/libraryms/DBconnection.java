/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package libraryms;

import java.sql.Connection;
import java.sql.DriverManager;
/**
 *
 * @author ACER
 */
public class DBconnection {
   static Connection con;
   
   public static Connection getconnection(){
       try {
            Class.forName("com.mysql.jdbc.Driver");
            con=DriverManager.getConnection("jdbc:mysql://localhost:3306/LibraryMS?zeroDateTimeBehavior=CONVERT_TO_NULL","root","");
       } catch (Exception e) {
         System.out.println("Sql connnection x1"+e);
       }
               
         return con;      
   }

}
