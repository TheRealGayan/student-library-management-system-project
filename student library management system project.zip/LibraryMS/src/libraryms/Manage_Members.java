/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package libraryms;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.RowFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;

/**
 *
 * @author ACER
 */
public class Manage_Members extends javax.swing.JFrame {

    DefaultTableModel model;
    
    public Manage_Members() {
        initComponents();
        setmember_details();
    }

    // Insert value for registration table
    public void registrationInfo(){
        int id=Integer.parseInt(idtxt.getText());
        String name=nametxt.getText();
        String address=addresstxt.getText();
        String email=emailtxt.getText();
        String contact=contacttxt.getText();
        try {
            Connection con=DBconnection.getconnection();
            String query="Insert into registration(Member_ID,Name,Address,Email,Contact)values(?,?,?,?,?)";
            PreparedStatement pst=con.prepareStatement(query);
            
            pst.setInt(1,id);
            pst.setString(2,name);
            pst.setString(3,address);
            pst.setString(4,email);
            pst.setString(5,contact);
            
            int RowCount=pst.executeUpdate();
            
            if(RowCount>0){
                JOptionPane.showMessageDialog(this,"Registration successfull");
               
            }
            
            else{
                JOptionPane.showMessageDialog(this,"Record not inserted");
            }
        } catch (Exception e) {
            System.out.println(""+e);
        }
      }
    
    //validations for manage_member page
       public boolean validations(){
        String id=idtxt.getText();
        String name=nametxt.getText();
        String address=addresstxt.getText();
        String email=emailtxt.getText();
        String contact=contacttxt.getText();
        
        if(id.equals("")){
           JOptionPane.showMessageDialog(this,"Enter member's ID");
           return false;
        }
         if(name.equals("")){
           JOptionPane.showMessageDialog(this,"Enter member's name");
           return false;
        }
          if(address.equals("")){
            JOptionPane.showMessageDialog(this,"Enter member's adderss");
            return false;
        } 
          if(email.equals("")){
            JOptionPane.showMessageDialog(this,"Enter member's Email");
            return false;
        }
       
          if(contact.equals("")){
            JOptionPane.showMessageDialog(this,"Enter member's contact number");
            return false;
        }
            return true;
       }
    
    //Set member_details to jtable
       public void setmember_details(){
           try {
                Class.forName("com.mysql.jdbc.Driver");
                Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/libraryms?zeroDateTimeBehavior=CONVERT_TO_NULL","root","");
                Statement st=con.createStatement();
                ResultSet rs=st.executeQuery("Select * from registration");
                
                while(rs.next()){
                    String id=rs.getString("Member_ID");
                    String name=rs.getString("Name");
                    String address=rs.getString("Address");
                    String email=rs.getString("Email");
                    String contact=rs.getString("Contact");
                    
                    Object[] obj={id,name,address,email,contact};
                    model=(DefaultTableModel)memberstbl.getModel();
                    model.addRow(obj);
                    
                    
                }
                
                
                
           } catch (Exception e) {
              System.out.println(""+e);
           }
       }
       
     
       //book update members
        public void updatemember(){
        int id=Integer.parseInt(idtxt.getText());
        String name=nametxt.getText();
        String address=addresstxt.getText();
        String email=emailtxt.getText();
        String contact=contacttxt.getText();
       try {
            Connection con=DBconnection.getconnection();
            String query=("Update registration set Name=?,Address=?,email=?,Contact=? where Member_ID=? ");
            PreparedStatement pst=con.prepareStatement(query);
            
            pst.setString(1,name);
            pst.setString(2,address);
            pst.setString(3,email);
            pst.setString(4,contact);
            pst.setInt(5,id);
          
            int RowCount=pst.executeUpdate();
            
            if(RowCount>0){
                JOptionPane.showMessageDialog(this,"Record updated");
               
            }
            
            else{
                JOptionPane.showMessageDialog(this,"Record not updated");
            }
        } catch (Exception e) {
            System.out.println(""+e);
        }
       } 
       
       
      // delete book_details method
       public void deletebooks(){
       
        int id=Integer.parseInt(idtxt.getText());
        String name=nametxt.getText();
        String address=addresstxt.getText();
        String email=emailtxt.getText();
        String contact=contacttxt.getText();
        try {
            Connection con=DBconnection.getconnection();
            String query="delete from registration where Member_ID=?";
            PreparedStatement pst=con.prepareStatement(query);
            
            pst.setInt(1,id);
           
            
            int RowCount=pst.executeUpdate();
            
            if(RowCount>0){
                JOptionPane.showMessageDialog(this,"Record deleted successfully");
               
            }
            
            else{
                JOptionPane.showMessageDialog(this,"Record not deleted");
            }
        } catch (Exception e) {
            System.out.println(""+e);
        }
      } 
        

       


    //clear table method
       public void clearTbl(){
        DefaultTableModel model=(DefaultTableModel)memberstbl.getModel();
        model.setRowCount(0);
      }
       
     //method to search field
       public void search(String str){
           model=(DefaultTableModel)memberstbl.getModel();
           TableRowSorter<DefaultTableModel> trs=new TableRowSorter<>(model);
           memberstbl.setRowSorter(trs);
           trs.setRowFilter(RowFilter.regexFilter(str));
       }
          
       
       @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        kGradientPanel1 = new keeptoo.KGradientPanel();
        kGradientPanel2 = new keeptoo.KGradientPanel();
        cancellbl = new javax.swing.JLabel();
        backbtn = new rojerusan.RSMaterialButtonCircle();
        jLabel1 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        contacttxt = new app.bolivia.swing.JCTextField();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        emailtxt = new app.bolivia.swing.JCTextField();
        jLabel11 = new javax.swing.JLabel();
        deletebtn = new rojerusan.RSMaterialButtonCircle();
        addtbtn = new rojerusan.RSMaterialButtonCircle();
        jLabel3 = new javax.swing.JLabel();
        addresstxt = new app.bolivia.swing.JCTextField();
        idtxt = new app.bolivia.swing.JCTextField();
        jLabel10 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        clearbtn1 = new rojerusan.RSMaterialButtonCircle();
        updatebtn = new rojerusan.RSMaterialButtonCircle();
        jLabel13 = new javax.swing.JLabel();
        nametxt = new app.bolivia.swing.JCTextField();
        jLabel14 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        memberstbl = new rojeru_san.complementos.RSTableMetro();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        searchtxt = new app.bolivia.swing.JCTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        kGradientPanel1.setkEndColor(new java.awt.Color(204, 204, 204));
        kGradientPanel1.setkStartColor(new java.awt.Color(255, 255, 255));
        kGradientPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        kGradientPanel2.setkEndColor(new java.awt.Color(0, 0, 51));
        kGradientPanel2.setkStartColor(new java.awt.Color(51, 0, 255));

        cancellbl.setFont(new java.awt.Font("Segoe UI Semibold", 1, 30)); // NOI18N
        cancellbl.setForeground(new java.awt.Color(153, 0, 0));
        cancellbl.setText("X");
        cancellbl.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cancellblMouseClicked(evt);
            }
        });

        backbtn.setText("Back");
        backbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backbtnActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Segoe UI Semibold", 1, 50)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(153, 0, 0));
        jLabel1.setText("Manage Members");

        javax.swing.GroupLayout kGradientPanel2Layout = new javax.swing.GroupLayout(kGradientPanel2);
        kGradientPanel2.setLayout(kGradientPanel2Layout);
        kGradientPanel2Layout.setHorizontalGroup(
            kGradientPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, kGradientPanel2Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(backbtn, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(417, 417, 417)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 428, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 462, Short.MAX_VALUE)
                .addComponent(cancellbl)
                .addGap(56, 56, 56))
        );
        kGradientPanel2Layout.setVerticalGroup(
            kGradientPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(kGradientPanel2Layout.createSequentialGroup()
                .addGroup(kGradientPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(backbtn, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1))
                .addGap(0, 13, Short.MAX_VALUE))
            .addGroup(kGradientPanel2Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(cancellbl, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        kGradientPanel1.add(kGradientPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1540, 80));

        jPanel3.setBackground(new java.awt.Color(0, 102, 102));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setBackground(new java.awt.Color(0, 0, 0));
        jLabel2.setFont(new java.awt.Font("Segoe UI Semibold", 1, 30)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("  Enter your correct details.");
        jPanel3.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 10, 410, -1));

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/icons/icons8_Google_Mobile_50px.png"))); // NOI18N
        jPanel3.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 540, -1, -1));

        contacttxt.setBackground(new java.awt.Color(0, 102, 102));
        contacttxt.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 2, 0, new java.awt.Color(255, 255, 255)));
        contacttxt.setFont(new java.awt.Font("Segoe UI Semibold", 1, 14)); // NOI18N
        contacttxt.setPlaceholder("Enter Member's Contact number");
        jPanel3.add(contacttxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 560, 310, 30));

        jLabel7.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Contact Number");
        jPanel3.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 520, -1, -1));

        jLabel8.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Address");
        jPanel3.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 270, -1, -1));

        jLabel9.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("Email");
        jPanel3.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 390, -1, -1));

        emailtxt.setBackground(new java.awt.Color(0, 102, 102));
        emailtxt.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 2, 0, new java.awt.Color(255, 255, 255)));
        emailtxt.setFont(new java.awt.Font("Segoe UI Semibold", 1, 14)); // NOI18N
        emailtxt.setPlaceholder("Enter Member's E-mail ");
        emailtxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                emailtxtActionPerformed(evt);
            }
        });
        jPanel3.add(emailtxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 430, 290, 30));

        jLabel11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/icons/icons8_Secured_Letter_50px.png"))); // NOI18N
        jPanel3.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 420, -1, 40));

        deletebtn.setBackground(new java.awt.Color(0, 204, 204));
        deletebtn.setText("Delete");
        deletebtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deletebtnActionPerformed(evt);
            }
        });
        jPanel3.add(deletebtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 640, 100, 60));

        addtbtn.setBackground(new java.awt.Color(0, 204, 51));
        addtbtn.setText("Add");
        addtbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addtbtnActionPerformed(evt);
            }
        });
        jPanel3.add(addtbtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 640, 110, 60));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/adminIcons/adminIcons/icons8_Library_32px.png"))); // NOI18N
        jPanel3.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 300, 40, 60));

        addresstxt.setBackground(new java.awt.Color(0, 102, 102));
        addresstxt.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 2, 0, new java.awt.Color(255, 255, 255)));
        addresstxt.setFont(new java.awt.Font("Segoe UI Semibold", 1, 14)); // NOI18N
        addresstxt.setPlaceholder("Enter Member's Address");
        jPanel3.add(addresstxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 310, 300, 30));

        idtxt.setBackground(new java.awt.Color(0, 102, 102));
        idtxt.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 2, 0, new java.awt.Color(255, 255, 255)));
        idtxt.setFont(new java.awt.Font("Segoe UI Semibold", 1, 14)); // NOI18N
        idtxt.setPlaceholder("Enter member's ID");
        jPanel3.add(idtxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 110, 300, 30));

        jLabel10.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("User ID");
        jPanel3.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 70, -1, -1));

        jLabel12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/icons/icons8_Account_50px.png"))); // NOI18N
        jPanel3.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 180, 50, 60));

        clearbtn1.setBackground(new java.awt.Color(153, 0, 51));
        clearbtn1.setText("Clear");
        clearbtn1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clearbtn1ActionPerformed(evt);
            }
        });
        jPanel3.add(clearbtn1, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 640, 110, 60));

        updatebtn.setBackground(new java.awt.Color(255, 102, 102));
        updatebtn.setText("Update");
        updatebtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updatebtnActionPerformed(evt);
            }
        });
        jPanel3.add(updatebtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 640, 100, 60));

        jLabel13.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(255, 255, 255));
        jLabel13.setText("User Name");
        jPanel3.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 170, -1, -1));

        nametxt.setBackground(new java.awt.Color(0, 102, 102));
        nametxt.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 2, 0, new java.awt.Color(255, 255, 255)));
        nametxt.setFont(new java.awt.Font("Segoe UI Semibold", 1, 14)); // NOI18N
        nametxt.setPlaceholder("Enter Member's Name");
        jPanel3.add(nametxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 210, 300, 30));

        jLabel14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/AddNewBookIcons/AddNewBookIcons/icons8_Contact_26px.png"))); // NOI18N
        jPanel3.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 100, -1, 40));

        kGradientPanel1.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 80, 560, 930));

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        memberstbl.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Member_ID", "Member_Name", "Address", "Emaill", "Contact"
            }
        ));
        memberstbl.setColorBackgoundHead(new java.awt.Color(0, 102, 102));
        memberstbl.setFont(new java.awt.Font("Segoe UI Semibold", 0, 25)); // NOI18N
        memberstbl.setFuenteFilas(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        memberstbl.setFuenteFilasSelect(new java.awt.Font("Segoe UI Semilight", 1, 20)); // NOI18N
        memberstbl.setFuenteHead(new java.awt.Font("Yu Gothic UI Semibold", 1, 20)); // NOI18N
        memberstbl.setRowHeight(40);
        memberstbl.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                memberstblMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(memberstbl);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 180, 840, -1));

        jLabel4.setFont(new java.awt.Font("Segoe UI Semibold", 1, 30)); // NOI18N
        jLabel4.setText("Members Details");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 130, 240, 40));

        jLabel5.setFont(new java.awt.Font("Segoe UI Semibold", 1, 24)); // NOI18N
        jLabel5.setText("Search");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 20, 80, 60));

        searchtxt.setFont(new java.awt.Font("Segoe UI Semibold", 1, 14)); // NOI18N
        searchtxt.setPlaceholder("Enter Member_Name");
        searchtxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                searchtxtKeyReleased(evt);
            }
        });
        jPanel1.add(searchtxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 30, 410, 50));

        kGradientPanel1.add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 80, 940, 920));

        getContentPane().add(kGradientPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1540, 1000));

        setSize(new java.awt.Dimension(1513, 1007));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void cancellblMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cancellblMouseClicked
        System.exit(0);
    }//GEN-LAST:event_cancellblMouseClicked
    
    //back button
    private void backbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backbtnActionPerformed
        LibrarianHome_page lb1=new LibrarianHome_page();
        lb1.setVisible(true);
        dispose();
    }//GEN-LAST:event_backbtnActionPerformed

    private void emailtxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_emailtxtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_emailtxtActionPerformed
     
    //delete button
    private void deletebtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deletebtnActionPerformed
       deletebooks();
       clearTbl();
       setmember_details();
    }//GEN-LAST:event_deletebtnActionPerformed
    
    //add button
    private void addtbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addtbtnActionPerformed
        if(validations()==true){
            registrationInfo();
            clearTbl();
            setmember_details();
        }
    }//GEN-LAST:event_addtbtnActionPerformed
    
    //clear button
    private void clearbtn1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clearbtn1ActionPerformed
        
        idtxt.setText("");
        nametxt.setText("");
        addresstxt.setText("");
        emailtxt.setText("");
        contacttxt.setText("");

        this.setVisible(true);
    }//GEN-LAST:event_clearbtn1ActionPerformed
    
    //member details to text fields
    private void memberstblMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_memberstblMouseClicked
        int rowno=memberstbl.getSelectedRow();
        TableModel model=memberstbl.getModel();
        
        idtxt.setText(model.getValueAt(rowno, 0).toString());
        nametxt.setText(model.getValueAt(rowno, 1).toString());
        addresstxt.setText(model.getValueAt(rowno, 2).toString());
        emailtxt.setText(model.getValueAt(rowno, 3).toString());
        contacttxt.setText(model.getValueAt(rowno, 4).toString());
                
    }//GEN-LAST:event_memberstblMouseClicked
    
    //update button
    private void updatebtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updatebtnActionPerformed
        updatemember();
        clearTbl();
        setmember_details();
    }//GEN-LAST:event_updatebtnActionPerformed
    
    //search bar 
    private void searchtxtKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_searchtxtKeyReleased
        String searcString=searchtxt.getText();
        search(searcString);
    }//GEN-LAST:event_searchtxtKeyReleased

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Manage_Members.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Manage_Members.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Manage_Members.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Manage_Members.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Manage_Members().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private app.bolivia.swing.JCTextField addresstxt;
    private rojerusan.RSMaterialButtonCircle addtbtn;
    private rojerusan.RSMaterialButtonCircle backbtn;
    private javax.swing.JLabel cancellbl;
    private rojerusan.RSMaterialButtonCircle clearbtn1;
    private app.bolivia.swing.JCTextField contacttxt;
    private rojerusan.RSMaterialButtonCircle deletebtn;
    private app.bolivia.swing.JCTextField emailtxt;
    private app.bolivia.swing.JCTextField idtxt;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private keeptoo.KGradientPanel kGradientPanel1;
    private keeptoo.KGradientPanel kGradientPanel2;
    private rojeru_san.complementos.RSTableMetro memberstbl;
    private app.bolivia.swing.JCTextField nametxt;
    private app.bolivia.swing.JCTextField searchtxt;
    private rojerusan.RSMaterialButtonCircle updatebtn;
    // End of variables declaration//GEN-END:variables
}
