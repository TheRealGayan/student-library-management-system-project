/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package libraryms;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.sql.Statement;
import java.sql.ResultSet;
import javax.swing.RowFilter;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;
/**
 *
 * @author ACER
 */
public class Manage_books extends javax.swing.JFrame {

    //int id;
    //String name;
   // String author;
    //int quantity;
    DefaultTableModel model;
    
    public Manage_books() {
        initComponents();
        setbook_details();
    }

    // Insert value for book_details table
    public void addbooks(){
       
        int id=Integer.parseInt(idtxt.getText());
        String name=nametxt.getText();
        String author=authortxt.getText();
        int quantity=Integer.parseInt(quantitytxt.getText());
        try {
            Connection con=DBconnection.getconnection();
            String query="Insert into book_details(Book_ID,Book_Name,Author,Quantity)values(?,?,?,?)";
            PreparedStatement pst=con.prepareStatement(query);
            
            pst.setInt(1,id);
            pst.setString(2,name);
            pst.setString(3,author);
            pst.setInt(4,quantity);
            
            int RowCount=pst.executeUpdate();
            
            if(RowCount>0){
                JOptionPane.showMessageDialog(this,"Record inserted successfully");
               
            }
            
            else{
                JOptionPane.showMessageDialog(this,"Record not inserted");
            }
        } catch (Exception e) {
            System.out.println(""+e);
        }
      }
    
    //validations for manage_book page
       public boolean validations(){
        String id=idtxt.getText();
        String name=nametxt.getText();
        String author=authortxt.getText();
        String quantity=quantitytxt.getText();
         
        if(id.equals("")){
           JOptionPane.showMessageDialog(this,"Enter book id");
           return false;
        }
          if(name.equals("")){
            JOptionPane.showMessageDialog(this,"Enter book name");
            return false;
        } 
          if(author.equals("")){
            JOptionPane.showMessageDialog(this,"Enter author's name");
            return false;
        }
       
          if(quantity.equals("")){
            JOptionPane.showMessageDialog(this,"Enter book quantity");
            return false;
        }
            return true;
       }
    
    //Set book_details to jtable
       public void setbook_details(){
           try {
                Class.forName("com.mysql.jdbc.Driver");
                Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/libraryms?zeroDateTimeBehavior=CONVERT_TO_NULL","root","");
                Statement st=con.createStatement();
                ResultSet rs=st.executeQuery("Select * from book_details");
                
                while(rs.next()){
                    String id=rs.getString("Book_ID");
                    String name=rs.getString("Book_Name");
                    String author=rs.getString("author");
                    String quantity=rs.getString("Quantity");
                    
                    Object[] obj={id,name,author,quantity};
                    model=(DefaultTableModel)bookdetailstbl.getModel();
                    model.addRow(obj);
                    
                    
                }
                
                
                
           } catch (Exception e) {
              System.out.println(""+e);
           }
       }
       
       //book_details update method
       public void updatebook(){
          int id=Integer.parseInt(idtxt.getText());
          String name=nametxt.getText();
          String author=authortxt.getText();
          int quantity=Integer.parseInt(quantitytxt.getText());
        try {
            Connection con=DBconnection.getconnection();
            String query=("Update book_details set Book_Name=?,Author=?,Quantity=? where Book_ID=? ");
            PreparedStatement pst=con.prepareStatement(query);
            
            pst.setString(1,name);
            pst.setString(2,author);
            pst.setInt(3,quantity);
            pst.setInt(4,id);
            
            int RowCount=pst.executeUpdate();
            
            if(RowCount>0){
                JOptionPane.showMessageDialog(this,"Record updated");
               
            }
            
            else{
                JOptionPane.showMessageDialog(this,"Record not updated");
            }
        } catch (Exception e) {
            System.out.println(""+e);
        }
       } 
       
       
        // delete book_details method
       public void deletebooks(){
       
        int id=Integer.parseInt(idtxt.getText());
        String name=nametxt.getText();
        String author=authortxt.getText();
        int quantity=Integer.parseInt(quantitytxt.getText());
        try {
            Connection con=DBconnection.getconnection();
            String query="delete from book_details where Book_ID=?";
            PreparedStatement pst=con.prepareStatement(query);
            
            pst.setInt(1,id);
           
            
            int RowCount=pst.executeUpdate();
            
            if(RowCount>0){
                JOptionPane.showMessageDialog(this,"Record deleted successfully");
               
            }
            
            else{
                JOptionPane.showMessageDialog(this,"Record not deleted");
            }
        } catch (Exception e) {
            System.out.println(""+e);
        }
      } 
        


    //clear table method
       public void clearTbl(){
         DefaultTableModel model=(DefaultTableModel)bookdetailstbl.getModel();
         model.setRowCount(0);
      }
       
     //method to search field
       public void search(String str){
           model=(DefaultTableModel)bookdetailstbl.getModel();
           TableRowSorter<DefaultTableModel> trs=new TableRowSorter<>(model);
           bookdetailstbl.setRowSorter(trs);
           trs.setRowFilter(RowFilter.regexFilter(str));
       }
            
       
       
       @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        kGradientPanel1 = new keeptoo.KGradientPanel();
        kGradientPanel2 = new keeptoo.KGradientPanel();
        cancellbl = new javax.swing.JLabel();
        backbtn = new rojerusan.RSMaterialButtonCircle();
        jLabel1 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        quantitytxt = new app.bolivia.swing.JCTextField();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        authortxt = new app.bolivia.swing.JCTextField();
        jLabel11 = new javax.swing.JLabel();
        deletebtn = new rojerusan.RSMaterialButtonCircle();
        addtbtn = new rojerusan.RSMaterialButtonCircle();
        jLabel3 = new javax.swing.JLabel();
        nametxt = new app.bolivia.swing.JCTextField();
        idtxt = new app.bolivia.swing.JCTextField();
        jLabel10 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        clearbtn = new rojerusan.RSMaterialButtonCircle();
        updatebtn = new rojerusan.RSMaterialButtonCircle();
        jPanel1 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        bookdetailstbl = new rojeru_san.complementos.RSTableMetro();
        jLabel5 = new javax.swing.JLabel();
        searchtxt = new app.bolivia.swing.JCTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        kGradientPanel1.setkEndColor(new java.awt.Color(204, 204, 204));
        kGradientPanel1.setkStartColor(new java.awt.Color(255, 255, 255));
        kGradientPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        kGradientPanel2.setkEndColor(new java.awt.Color(0, 0, 51));
        kGradientPanel2.setkStartColor(new java.awt.Color(51, 0, 255));

        cancellbl.setFont(new java.awt.Font("Segoe UI Semibold", 1, 30)); // NOI18N
        cancellbl.setForeground(new java.awt.Color(153, 0, 0));
        cancellbl.setText("X");
        cancellbl.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cancellblMouseClicked(evt);
            }
        });

        backbtn.setText("Back");
        backbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backbtnActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Segoe UI Semibold", 1, 50)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(153, 0, 0));
        jLabel1.setText("Manage Books");

        javax.swing.GroupLayout kGradientPanel2Layout = new javax.swing.GroupLayout(kGradientPanel2);
        kGradientPanel2.setLayout(kGradientPanel2Layout);
        kGradientPanel2Layout.setHorizontalGroup(
            kGradientPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, kGradientPanel2Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(backbtn, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(441, 441, 441)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 361, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 506, Short.MAX_VALUE)
                .addComponent(cancellbl)
                .addGap(55, 55, 55))
        );
        kGradientPanel2Layout.setVerticalGroup(
            kGradientPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(kGradientPanel2Layout.createSequentialGroup()
                .addGroup(kGradientPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(backbtn, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1))
                .addGap(0, 13, Short.MAX_VALUE))
            .addGroup(kGradientPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(cancellbl, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        kGradientPanel1.add(kGradientPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1540, 80));

        jPanel3.setBackground(new java.awt.Color(0, 102, 102));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setBackground(new java.awt.Color(0, 0, 0));
        jLabel2.setFont(new java.awt.Font("Segoe UI Semibold", 1, 30)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("  Enter your correct details.");
        jPanel3.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 40, 410, -1));

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/AddNewBookIcons/AddNewBookIcons/icons8_Unit_26px.png"))); // NOI18N
        jPanel3.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 560, -1, -1));

        quantitytxt.setBackground(new java.awt.Color(0, 102, 102));
        quantitytxt.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 2, 0, new java.awt.Color(255, 255, 255)));
        quantitytxt.setFont(new java.awt.Font("Segoe UI Semibold", 1, 14)); // NOI18N
        quantitytxt.setPlaceholder("Enter Book Quantity");
        jPanel3.add(quantitytxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 560, 300, 30));

        jLabel7.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Quantity");
        jPanel3.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 520, -1, -1));

        jLabel8.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Book Name");
        jPanel3.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 250, -1, -1));

        jLabel9.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("Author");
        jPanel3.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 380, -1, -1));

        authortxt.setBackground(new java.awt.Color(0, 102, 102));
        authortxt.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 2, 0, new java.awt.Color(255, 255, 255)));
        authortxt.setFont(new java.awt.Font("Segoe UI Semibold", 1, 14)); // NOI18N
        authortxt.setPlaceholder("Enter Author's Name");
        authortxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                authortxtActionPerformed(evt);
            }
        });
        jPanel3.add(authortxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 430, 290, 30));

        jLabel11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/AddNewBookIcons/AddNewBookIcons/icons8_Contact_26px.png"))); // NOI18N
        jPanel3.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 170, -1, 40));

        deletebtn.setBackground(new java.awt.Color(0, 204, 204));
        deletebtn.setText("Delete");
        deletebtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deletebtnActionPerformed(evt);
            }
        });
        jPanel3.add(deletebtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 640, 100, 60));

        addtbtn.setBackground(new java.awt.Color(0, 204, 51));
        addtbtn.setText("Add");
        addtbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addtbtnActionPerformed(evt);
            }
        });
        jPanel3.add(addtbtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 640, 100, 60));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/AddNewBookIcons/AddNewBookIcons/icons8_Moleskine_26px.png"))); // NOI18N
        jPanel3.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 280, 40, 60));

        nametxt.setBackground(new java.awt.Color(0, 102, 102));
        nametxt.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 2, 0, new java.awt.Color(255, 255, 255)));
        nametxt.setFont(new java.awt.Font("Segoe UI Semibold", 1, 14)); // NOI18N
        nametxt.setPlaceholder("Enter Book Name");
        jPanel3.add(nametxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 300, 300, 30));

        idtxt.setBackground(new java.awt.Color(0, 102, 102));
        idtxt.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 2, 0, new java.awt.Color(255, 255, 255)));
        idtxt.setFont(new java.awt.Font("Segoe UI Semibold", 1, 14)); // NOI18N
        idtxt.setPlaceholder("Enter Book ID");
        jPanel3.add(idtxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 180, 300, 30));

        jLabel10.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("Book ID");
        jPanel3.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 130, -1, -1));

        jLabel12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/AddNewBookIcons/AddNewBookIcons/icons8_Collaborator_Male_26px.png"))); // NOI18N
        jPanel3.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 410, 50, 60));

        clearbtn.setBackground(new java.awt.Color(153, 0, 51));
        clearbtn.setText("Clear");
        clearbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clearbtnActionPerformed(evt);
            }
        });
        jPanel3.add(clearbtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 640, 100, 60));

        updatebtn.setBackground(new java.awt.Color(255, 102, 102));
        updatebtn.setText("Update");
        updatebtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updatebtnActionPerformed(evt);
            }
        });
        jPanel3.add(updatebtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 640, 100, 60));

        kGradientPanel1.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 80, 560, 930));

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        jLabel4.setFont(new java.awt.Font("Segoe UI Semibold", 1, 30)); // NOI18N
        jLabel4.setText("Book Details");

        bookdetailstbl.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Book_ID", "Book_Name", "Author", "Quantity"
            }
        ));
        bookdetailstbl.setColorBackgoundHead(new java.awt.Color(0, 102, 102));
        bookdetailstbl.setFont(new java.awt.Font("Segoe UI Semibold", 0, 25)); // NOI18N
        bookdetailstbl.setFuenteFilas(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        bookdetailstbl.setFuenteFilasSelect(new java.awt.Font("Segoe UI Semilight", 1, 20)); // NOI18N
        bookdetailstbl.setFuenteHead(new java.awt.Font("Yu Gothic UI Semibold", 1, 20)); // NOI18N
        bookdetailstbl.setRowHeight(40);
        bookdetailstbl.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                bookdetailstblMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(bookdetailstbl);

        jLabel5.setFont(new java.awt.Font("Segoe UI Semibold", 1, 24)); // NOI18N
        jLabel5.setText("Search");

        searchtxt.setFont(new java.awt.Font("Segoe UI Semibold", 1, 14)); // NOI18N
        searchtxt.setPlaceholder("Enter Book_Name");
        searchtxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                searchtxtKeyReleased(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(333, 333, 333))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(61, 61, 61)
                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(searchtxt, javax.swing.GroupLayout.PREFERRED_SIZE, 410, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(47, 47, 47)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 813, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(80, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(searchtxt, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(26, 26, 26)
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 465, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(286, Short.MAX_VALUE))
        );

        kGradientPanel1.add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 80, 940, 920));

        getContentPane().add(kGradientPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1540, 1000));

        setSize(new java.awt.Dimension(1514, 1007));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents
    //cancel button
    private void cancellblMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cancellblMouseClicked
        System.exit(0);
    }//GEN-LAST:event_cancellblMouseClicked
    
    //back button
    private void backbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backbtnActionPerformed
        LibrarianHome_page hp1=new LibrarianHome_page();
        hp1.setVisible(true);
        dispose();
    }//GEN-LAST:event_backbtnActionPerformed

    private void authortxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_authortxtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_authortxtActionPerformed
    
    //delete button
    private void deletebtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deletebtnActionPerformed
         deletebooks();
         clearTbl();
         setbook_details();
    }//GEN-LAST:event_deletebtnActionPerformed
    
    //add button
    private void addtbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addtbtnActionPerformed
        if(validations()==true){
            addbooks();
            clearTbl();
            setbook_details();
           
        }
    }//GEN-LAST:event_addtbtnActionPerformed
    
    //clear button
    private void clearbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clearbtnActionPerformed
        idtxt.setText("");
        nametxt.setText("");
        authortxt.setText("");
        quantitytxt.setText("");

        this.setVisible(true);
    }//GEN-LAST:event_clearbtnActionPerformed
    
    //book details to text fields
    private void bookdetailstblMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_bookdetailstblMouseClicked
        int rowno=bookdetailstbl.getSelectedRow();
        TableModel model=bookdetailstbl.getModel();
        
        idtxt.setText(model.getValueAt(rowno, 0).toString());
        nametxt.setText(model.getValueAt(rowno, 1).toString());
        authortxt.setText(model.getValueAt(rowno, 2).toString());
        quantitytxt.setText(model.getValueAt(rowno, 3).toString());
        
    }//GEN-LAST:event_bookdetailstblMouseClicked

    private void updatebtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updatebtnActionPerformed
            
           updatebook();
           clearTbl();
           setbook_details(); 
            
           
        
    }//GEN-LAST:event_updatebtnActionPerformed

    private void searchtxtKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_searchtxtKeyReleased
        String searcString=searchtxt.getText();
        search(searcString);
    }//GEN-LAST:event_searchtxtKeyReleased

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Manage_books.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Manage_books.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Manage_books.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Manage_books.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Manage_books().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private rojerusan.RSMaterialButtonCircle addtbtn;
    private app.bolivia.swing.JCTextField authortxt;
    private rojerusan.RSMaterialButtonCircle backbtn;
    private rojeru_san.complementos.RSTableMetro bookdetailstbl;
    private javax.swing.JLabel cancellbl;
    private rojerusan.RSMaterialButtonCircle clearbtn;
    private rojerusan.RSMaterialButtonCircle deletebtn;
    private app.bolivia.swing.JCTextField idtxt;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private keeptoo.KGradientPanel kGradientPanel1;
    private keeptoo.KGradientPanel kGradientPanel2;
    private app.bolivia.swing.JCTextField nametxt;
    private app.bolivia.swing.JCTextField quantitytxt;
    private app.bolivia.swing.JCTextField searchtxt;
    private rojerusan.RSMaterialButtonCircle updatebtn;
    // End of variables declaration//GEN-END:variables
}
