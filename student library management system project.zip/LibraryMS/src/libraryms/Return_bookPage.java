/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package libraryms;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.*;
import javax.swing.JOptionPane;
import java.sql.*;
/**
 *
 * @author ACER
 */
public class Return_bookPage extends javax.swing.JFrame {

    /**
     * Creates new form Borrow_bookPage
     */
    public Return_bookPage() {
        initComponents();
    }
 
    //get borrowbook_details from the database and display it on pannel
    public void getBorrowBook_details(){
       int book_id=Integer.parseInt(Book_IDtxt.getText());
       int member_id=Integer.parseInt(Member_IDtxt.getText());
       
       try {
           Connection con=DBconnection.getconnection();
           String sql="Select * from borrowbook_details where Book_ID=? and Member_ID=? and Status=?";
           
           PreparedStatement pst=con.prepareStatement(sql);
           pst.setInt(1,book_id);
           pst.setInt(2,member_id);
           pst.setString(3,"pending");
           
           ResultSet rs=pst.executeQuery();
           if(rs.next()){
               borrowbook_IDlbl.setText(rs.getString("Book_ID"));
               Book_Namelbl.setText(rs.getString("Book_Name"));
               member_namelbl.setText(rs.getString("Member_Name"));
               borrow_bookdatelbl.setText(rs.getString("Borrow_Date"));
               due_datelbl.setText(rs.getString("Due_Date"));
               error_bookmessagelbl.setText("");
           }
           else{
               error_bookmessagelbl.setText("Record Not found");
           
               borrowbook_IDlbl.setText("");
               Book_Namelbl.setText("");
               member_namelbl.setText("");
               borrow_bookdatelbl.setText("");
               due_datelbl.setText("");
           }
       } catch (Exception e) {
           System.out.println(""+ e);
       }
   }
    
   
    //return the book
    public boolean returnbook(){
        boolean isreturned=false;
        int book_id=Integer.parseInt(Book_IDtxt.getText());
        int member_id=Integer.parseInt(Member_IDtxt.getText());
        
        try {
             Connection con=DBconnection.getconnection();
             String sql="Update borrowbook_details set Status=? where Member_ID=? and Book_ID=? and Status=?";
             PreparedStatement pst=con.prepareStatement(sql);
             pst.setString(1,"Returned");
             pst.setInt(2,member_id);
             pst.setInt(3,book_id);
             pst.setString(4,"Pending");
             
             int rowcount=pst.executeUpdate();
             if(rowcount>0){
                 isreturned=true;
             }
             else{
                 isreturned=false;
             }         
            
        } catch (Exception e) {
            System.out.println(""+e);
        }
           
        return isreturned;    
     }
    
   
              
    
    // update book count method
    public void update_bookcount(){
        int bookid=Integer.parseInt(Book_IDtxt.getText());
        
        try {
           Connection con=DBconnection.getconnection();
           String query="Update book_details set Quantity=Quantity+1 where Book_ID=?";
           PreparedStatement pst=con.prepareStatement(query);
           
           pst.setInt(1,bookid);
           
           int RowCount=pst.executeUpdate();
            
            if(RowCount>0){
                //JOptionPane.showMessageDialog(this,"Book count updated successfully");
               
            }
            
            else{
                //JOptionPane.showMessageDialog(this,"Book count not updated");
            }
              
        } catch (Exception e) {
          System.out.println(""+e);
        }
    }
    
    
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        kGradientPanel2 = new keeptoo.KGradientPanel();
        cancellbl = new javax.swing.JLabel();
        backbtn = new rojerusan.RSMaterialButtonCircle();
        jLabel1 = new javax.swing.JLabel();
        kGradientPanel1 = new keeptoo.KGradientPanel();
        jLabel4 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        Member_IDtxt = new javax.swing.JTextField();
        Book_IDtxt = new javax.swing.JTextField();
        findbtn = new rojerusan.RSMaterialButtonCircle();
        returnbookbtn1 = new rojerusan.RSMaterialButtonCircle();
        kGradientPanel4 = new keeptoo.KGradientPanel();
        Book_Namelbl = new javax.swing.JLabel();
        member_namelbl = new javax.swing.JLabel();
        borrowbook_IDlbl = new javax.swing.JLabel();
        due_datelbl = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        borrow_bookdatelbl = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        Book_IDlbl1 = new javax.swing.JLabel();
        error_bookmessagelbl = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        kGradientPanel2.setkEndColor(new java.awt.Color(0, 0, 51));
        kGradientPanel2.setkStartColor(new java.awt.Color(51, 0, 255));
        kGradientPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        cancellbl.setFont(new java.awt.Font("Segoe UI Semibold", 1, 30)); // NOI18N
        cancellbl.setForeground(new java.awt.Color(153, 0, 0));
        cancellbl.setText("X");
        cancellbl.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cancellblMouseClicked(evt);
            }
        });
        kGradientPanel2.add(cancellbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(1474, 15, -1, 30));

        backbtn.setText("Back");
        backbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backbtnActionPerformed(evt);
            }
        });
        kGradientPanel2.add(backbtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(22, 16, 136, 51));

        jLabel1.setFont(new java.awt.Font("Segoe UI Semibold", 1, 50)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(153, 0, 0));
        jLabel1.setText("Return Books");
        kGradientPanel2.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 0, 428, -1));

        getContentPane().add(kGradientPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1540, 80));

        kGradientPanel1.setkEndColor(new java.awt.Color(204, 255, 255));
        kGradientPanel1.setkStartColor(new java.awt.Color(255, 255, 255));
        kGradientPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel4.setFont(new java.awt.Font("Segoe UI Semibold", 1, 30)); // NOI18N
        jLabel4.setText("Return Book");
        kGradientPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 50, 190, 30));

        jLabel23.setBackground(new java.awt.Color(0, 0, 0));
        jLabel23.setFont(new java.awt.Font("Segoe UI Semibold", 1, 18)); // NOI18N
        jLabel23.setText("Member ID");
        kGradientPanel1.add(jLabel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 260, 100, 30));

        jLabel24.setFont(new java.awt.Font("Segoe UI Semibold", 1, 18)); // NOI18N
        jLabel24.setText("Book ID");
        kGradientPanel1.add(jLabel24, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 180, 100, 30));

        Member_IDtxt.setFont(new java.awt.Font("Segoe UI Semibold", 3, 20)); // NOI18N
        Member_IDtxt.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 2, 0, new java.awt.Color(0, 0, 0)));
        Member_IDtxt.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                Member_IDtxtFocusLost(evt);
            }
        });
        kGradientPanel1.add(Member_IDtxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 260, 190, 30));

        Book_IDtxt.setFont(new java.awt.Font("Segoe UI Semibold", 1, 20)); // NOI18N
        Book_IDtxt.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 2, 0, new java.awt.Color(0, 0, 0)));
        Book_IDtxt.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                Book_IDtxtFocusLost(evt);
            }
        });
        kGradientPanel1.add(Book_IDtxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 180, 190, 30));

        findbtn.setBackground(new java.awt.Color(153, 0, 0));
        findbtn.setText("Find details");
        findbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                findbtnActionPerformed(evt);
            }
        });
        kGradientPanel1.add(findbtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 360, 210, 60));

        returnbookbtn1.setBackground(new java.awt.Color(0, 102, 51));
        returnbookbtn1.setText("Return Book");
        returnbookbtn1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                returnbookbtn1ActionPerformed(evt);
            }
        });
        kGradientPanel1.add(returnbookbtn1, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 460, 210, 60));

        getContentPane().add(kGradientPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(1050, 80, 450, 920));

        kGradientPanel4.setkEndColor(new java.awt.Color(0, 102, 102));
        kGradientPanel4.setkStartColor(new java.awt.Color(0, 102, 102));
        kGradientPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Book_Namelbl.setFont(new java.awt.Font("Segoe UI Semibold", 0, 20)); // NOI18N
        Book_Namelbl.setForeground(new java.awt.Color(255, 255, 255));
        kGradientPanel4.add(Book_Namelbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 260, 190, 30));

        member_namelbl.setFont(new java.awt.Font("Segoe UI Semibold", 1, 20)); // NOI18N
        member_namelbl.setForeground(new java.awt.Color(255, 255, 255));
        kGradientPanel4.add(member_namelbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 330, 190, 30));

        borrowbook_IDlbl.setFont(new java.awt.Font("Segoe UI Semibold", 1, 20)); // NOI18N
        borrowbook_IDlbl.setForeground(new java.awt.Color(255, 255, 255));
        kGradientPanel4.add(borrowbook_IDlbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 190, 180, 30));

        due_datelbl.setFont(new java.awt.Font("Segoe UI Semibold", 1, 20)); // NOI18N
        due_datelbl.setForeground(new java.awt.Color(255, 255, 255));
        kGradientPanel4.add(due_datelbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 470, 190, 30));

        jLabel2.setFont(new java.awt.Font("Segoe UI Semibold", 1, 30)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Book Details");
        kGradientPanel4.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 50, 190, 50));

        jLabel7.setFont(new java.awt.Font("Segoe UI Semibold", 1, 20)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Book_Name :");
        kGradientPanel4.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 260, 120, 30));

        jLabel8.setFont(new java.awt.Font("Segoe UI Semibold", 1, 20)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Member Name :");
        kGradientPanel4.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 330, 150, 30));

        jLabel5.setFont(new java.awt.Font("Segoe UI Semibold", 1, 20)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Due Date :");
        kGradientPanel4.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 470, 140, 30));

        jLabel9.setFont(new java.awt.Font("Segoe UI Semibold", 1, 20)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("Borrow Date :");
        kGradientPanel4.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 400, 140, 30));

        borrow_bookdatelbl.setFont(new java.awt.Font("Segoe UI Semibold", 1, 20)); // NOI18N
        borrow_bookdatelbl.setForeground(new java.awt.Color(255, 255, 255));
        kGradientPanel4.add(borrow_bookdatelbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 400, 200, 30));

        jLabel10.setFont(new java.awt.Font("Segoe UI Semibold", 1, 20)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("Borrow Book_ID :");
        kGradientPanel4.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 190, 160, 30));

        Book_IDlbl1.setFont(new java.awt.Font("Segoe UI Semibold", 1, 20)); // NOI18N
        Book_IDlbl1.setForeground(new java.awt.Color(255, 255, 255));
        kGradientPanel4.add(Book_IDlbl1, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 180, 220, 30));

        error_bookmessagelbl.setBackground(new java.awt.Color(255, 255, 255));
        error_bookmessagelbl.setFont(new java.awt.Font("Segoe UI Semibold", 1, 20)); // NOI18N
        error_bookmessagelbl.setForeground(new java.awt.Color(255, 255, 255));
        kGradientPanel4.add(error_bookmessagelbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 580, 310, 30));

        getContentPane().add(kGradientPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 80, 500, 920));

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/icons/Return_book.png"))); // NOI18N
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(-20, 210, 530, 510));

        setSize(new java.awt.Dimension(1515, 1007));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void cancellblMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cancellblMouseClicked
        System.exit(0);
    }//GEN-LAST:event_cancellblMouseClicked
    
    //back button
    private void backbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backbtnActionPerformed
        UserHome_page uh1=new UserHome_page();
        uh1.setVisible(true);
        dispose();
    }//GEN-LAST:event_backbtnActionPerformed

    private void Book_IDtxtFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_Book_IDtxtFocusLost
        
    }//GEN-LAST:event_Book_IDtxtFocusLost

    private void Member_IDtxtFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_Member_IDtxtFocusLost
       
        
    }//GEN-LAST:event_Member_IDtxtFocusLost
    
    //find details book
    private void findbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_findbtnActionPerformed
       getBorrowBook_details();
    }//GEN-LAST:event_findbtnActionPerformed
    
    //return book button
    private void returnbookbtn1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_returnbookbtn1ActionPerformed
        if(returnbook()==true){
          JOptionPane.showMessageDialog(this,"Book returned successfully");
          update_bookcount();
        }
        else{
             JOptionPane.showMessageDialog(this,"Book returned fail");
            } 
    }//GEN-LAST:event_returnbookbtn1ActionPerformed
       
   
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Return_bookPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Return_bookPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Return_bookPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Return_bookPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Return_bookPage().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Book_IDlbl1;
    private javax.swing.JTextField Book_IDtxt;
    private javax.swing.JLabel Book_Namelbl;
    private javax.swing.JTextField Member_IDtxt;
    private rojerusan.RSMaterialButtonCircle backbtn;
    private javax.swing.JLabel borrow_bookdatelbl;
    private javax.swing.JLabel borrowbook_IDlbl;
    private javax.swing.JLabel cancellbl;
    private javax.swing.JLabel due_datelbl;
    private javax.swing.JLabel error_bookmessagelbl;
    private rojerusan.RSMaterialButtonCircle findbtn;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private keeptoo.KGradientPanel kGradientPanel1;
    private keeptoo.KGradientPanel kGradientPanel2;
    private keeptoo.KGradientPanel kGradientPanel4;
    private javax.swing.JLabel member_namelbl;
    private rojerusan.RSMaterialButtonCircle returnbookbtn1;
    // End of variables declaration//GEN-END:variables
}
