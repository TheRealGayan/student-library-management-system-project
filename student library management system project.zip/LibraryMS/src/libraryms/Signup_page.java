/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package libraryms;

import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.swing.JOptionPane;

/**
 *
 * @author ACER
 */
public class Signup_page extends javax.swing.JFrame {

   
    public Signup_page() {
        initComponents();
    }
    
   
   //signup table insert value method
    public void SignupInfor(){
        String name=nametxt.getText();
        String pwd=pwdtxt.getText();
        String email=emailtxt.getText();
        String ltype=ltypecheckbox.getText();
        try {
            Connection con=DBconnection.getconnection();
            String query="Insert into signup(Name,password,Email,LoginType)values(?,?,?,?)";
            PreparedStatement pst=con.prepareStatement(query);
            
            pst.setString(1,name);
            pst.setString(2,pwd);
            pst.setString(3,email);
            pst.setString(4,ltype);
            
            int RowCount=pst.executeUpdate();
            
            if(RowCount>0){
                JOptionPane.showMessageDialog(this,"You are successfully signup");
                Login_page page1=new Login_page();
                page1.setVisible(true);
                dispose();
            }
            
            else{
                JOptionPane.showMessageDialog(this,"Record not inserted");
            }
        } catch (Exception e) {
            System.out.println("Signup error"+e);
        }
        
    }
       //validations for signup page
       public boolean validations(){
        String name=nametxt.getText();
        String pwd=pwdtxt.getText();
        String email=emailtxt.getText();
        String ltype=ltypecheckbox.getText();
         
        if(name.equals("")){
           JOptionPane.showMessageDialog(this,"Enter your Name");
           return false;
        }
          if(pwd.equals("")){
            JOptionPane.showMessageDialog(this,"Enter your Password");
            return false;
        } 
          if(email.equals("")){
            JOptionPane.showMessageDialog(this,"Enter your Email");
            return false;
        }
       
          if(ltype.equals("")){
            JOptionPane.showMessageDialog(this,"Select your login type");
            return false;
        }
            return true;
       }
    
     
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        nametxt = new app.bolivia.swing.JCTextField();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        emailtxt = new app.bolivia.swing.JCTextField();
        jLabel11 = new javax.swing.JLabel();
        signupbtn = new rojerusan.RSMaterialButtonCircle();
        loginbtn = new rojerusan.RSMaterialButtonCircle();
        exitlbl = new javax.swing.JLabel();
        pwdtxt = new javax.swing.JPasswordField();
        ltypecheckbox = new javax.swing.JCheckBox();
        jLabel3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Verdana", 1, 28)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(204, 0, 51));
        jLabel1.setText("Library Management System");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 50, 460, 40));

        jLabel13.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/icons/library.png"))); // NOI18N
        jPanel1.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(-170, 130, 740, 880));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 550, 800));

        jPanel3.setBackground(new java.awt.Color(0, 102, 102));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setBackground(new java.awt.Color(0, 0, 0));
        jLabel2.setFont(new java.awt.Font("Segoe UI Semibold", 1, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Member signup Page");
        jPanel3.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 50, 250, -1));

        jLabel4.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Password");
        jPanel3.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 270, -1, -1));

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/icons/icons8_Secure_50px.png"))); // NOI18N
        jPanel3.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 280, -1, -1));

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/icons/icons8_Account_50px.png"))); // NOI18N
        jPanel3.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 500, -1, -1));

        nametxt.setBackground(new java.awt.Color(0, 102, 102));
        nametxt.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 2, 0, new java.awt.Color(255, 255, 255)));
        nametxt.setFont(new java.awt.Font("Segoe UI Semibold", 1, 14)); // NOI18N
        nametxt.setPlaceholder("Enter Your name");
        jPanel3.add(nametxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 190, 160, 30));

        jLabel7.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Login Type");
        jPanel3.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 480, -1, -1));

        jLabel8.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("User Name");
        jPanel3.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 160, -1, -1));

        jLabel9.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("Email");
        jPanel3.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 370, -1, -1));

        emailtxt.setBackground(new java.awt.Color(0, 102, 102));
        emailtxt.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 2, 0, new java.awt.Color(255, 255, 255)));
        emailtxt.setFont(new java.awt.Font("Segoe UI Semibold", 1, 14)); // NOI18N
        emailtxt.setPlaceholder("Enter Your E-mail\n");
        emailtxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                emailtxtActionPerformed(evt);
            }
        });
        jPanel3.add(emailtxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 400, 160, 30));

        jLabel11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/icons/icons8_Secured_Letter_50px.png"))); // NOI18N
        jPanel3.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 390, -1, 40));

        signupbtn.setBackground(new java.awt.Color(51, 204, 255));
        signupbtn.setText("Signup");
        signupbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                signupbtnActionPerformed(evt);
            }
        });
        jPanel3.add(signupbtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 650, 110, 60));

        loginbtn.setBackground(new java.awt.Color(0, 204, 51));
        loginbtn.setText("Login");
        loginbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                loginbtnActionPerformed(evt);
            }
        });
        jPanel3.add(loginbtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 650, 110, 60));

        exitlbl.setFont(new java.awt.Font("Segoe UI Semibold", 1, 32)); // NOI18N
        exitlbl.setForeground(new java.awt.Color(153, 0, 51));
        exitlbl.setText("X");
        exitlbl.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                exitlblMouseClicked(evt);
            }
        });
        jPanel3.add(exitlbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 0, 40, 50));

        pwdtxt.setBackground(new java.awt.Color(0, 102, 102));
        pwdtxt.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 2, 0, new java.awt.Color(255, 255, 255)));
        pwdtxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pwdtxtActionPerformed(evt);
            }
        });
        jPanel3.add(pwdtxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 290, 170, 30));

        ltypecheckbox.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        ltypecheckbox.setForeground(new java.awt.Color(255, 255, 255));
        ltypecheckbox.setText("Member");
        ltypecheckbox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ltypecheckboxActionPerformed(evt);
            }
        });
        jPanel3.add(ltypecheckbox, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 520, 150, 40));

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/icons/icons8_Account_50px.png"))); // NOI18N
        jPanel3.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 170, 50, 60));

        getContentPane().add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 0, 390, 800));

        setSize(new java.awt.Dimension(940, 800));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents
     
    private void emailtxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_emailtxtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_emailtxtActionPerformed
    
    //signup button
    private void signupbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_signupbtnActionPerformed
       if(validations()==true){    
        SignupInfor();
       }
    }//GEN-LAST:event_signupbtnActionPerformed
    
    //exit button
    private void exitlblMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_exitlblMouseClicked
        System.exit(0);
    }//GEN-LAST:event_exitlblMouseClicked
    
    //login button
    private void loginbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_loginbtnActionPerformed
        Login_page lpg1=new Login_page();
        lpg1.setVisible(true);
        dispose();
        
    }//GEN-LAST:event_loginbtnActionPerformed

    private void pwdtxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pwdtxtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_pwdtxtActionPerformed

    private void ltypecheckboxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ltypecheckboxActionPerformed
           // TODO add your handling code here:
    }//GEN-LAST:event_ltypecheckboxActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Signup_page.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Signup_page.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Signup_page.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Signup_page.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Signup_page().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private app.bolivia.swing.JCTextField emailtxt;
    private javax.swing.JLabel exitlbl;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private rojerusan.RSMaterialButtonCircle loginbtn;
    private javax.swing.JCheckBox ltypecheckbox;
    private app.bolivia.swing.JCTextField nametxt;
    private javax.swing.JPasswordField pwdtxt;
    private rojerusan.RSMaterialButtonCircle signupbtn;
    // End of variables declaration//GEN-END:variables

}